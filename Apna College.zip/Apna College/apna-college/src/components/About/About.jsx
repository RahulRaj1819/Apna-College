import React from 'react'
import './About.css'
import about_img from '../../assets/about.png'
import play_icon from '../../assets/play-icon.png'


function About() {
  return (
    <div className='container'>
   
   <div className='about'>
        <div className="about-left">
        <img src={about_img} alt="" className='img1'/>
        <img src={play_icon} alt="" className='play-icon'/>
        </div>
        <div className="about-right">
        <h2>About College</h2>
        <h3>Bechlor of technology</h3>
      <p>Bhagwan Parshuram Institute of Technology, Delhi was established by the Bhartiya Brahmin
         Charitable Trust in 2007 with the aim to impart value-based education and to prepare the most competent 
         and ingenious technocrats and leaders of the country.
      BPIT as an ‘A’ grade institute of GGSIPU offers courses of Bachelor of 
      Technology (B.Tech) and Master of Business Administration (MBA), which are approved by the 
      All India Council of Technical Education (AICTE).</p>
      <p>The Institute is ranked between a bracket of 251-300 in NIRF ranking 2021 among all engineering institutes in India.
      Spread over an area of about 6 acres, the institute has an excelled infrastructure and is equipped with state of art 
      facilities such as lecture halls with multimedia facilities; laboratories with modern instruments; 
      well-furnished seminar halls; a spacious conference room and a duly maintained girls’ hostel.</p>
      </div></div>
    </div>
  )
}

export default About
